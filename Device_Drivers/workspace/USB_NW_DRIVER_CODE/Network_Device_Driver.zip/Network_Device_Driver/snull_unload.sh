#!/bin/sh

ifconfig eth0 down
ifconfig eth1 down
rmmod snull

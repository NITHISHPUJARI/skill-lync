#ifndef RECTANGLE_H
#define RECTANGLE_H

double rectangle_area(double length, double width);
double rectangle_perimeter(double length, double width);

#endif /* RECTANGLE_H */

#ifndef SQUARE_H
#define SQUARE_H

double square_area(double side);
double square_perimeter(double side);

#endif /* SQUARE_H */

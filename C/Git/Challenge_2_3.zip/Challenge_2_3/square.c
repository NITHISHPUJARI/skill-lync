#include "square.h"

double square_area(double side) {
    return side * side;
}

double square_perimeter(double side) {
    return 4 * side;
}

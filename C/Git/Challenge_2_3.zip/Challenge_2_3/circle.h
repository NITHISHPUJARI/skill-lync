#ifndef CIRCLE_H
#define CIRCLE_H

double circle_area(double radius);
double circle_perimeter(double radius);

#endif /* CIRCLE_H */
